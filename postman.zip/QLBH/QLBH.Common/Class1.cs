﻿using System;

namespace QLBH.Common
{
    public class Class1
    {
    }
}
